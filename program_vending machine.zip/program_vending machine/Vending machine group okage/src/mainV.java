
import jdk.dynalink.beans.StaticClass;

import java.util.ArrayList;
import java.util.Scanner;
public class mainV {
    //final keyboard able to be used everywhere
    public static final Scanner keyboard= new Scanner(System.in);

    public static int qProducts,balance=1000,quantity,b_hundreds=100,b_fifties=100,b_twenties=100,b_tens=100,b_fives=100,b_ones=100,b_fiftyCents=100,b_tenCents=100,b_fiveCents=100;
    public static String productName;
    public static double  pricePerItem,total,ogChange,change,hundreds,fifties,twenties,tens,fives,ones,fiftyCent,tenCents, fiveCents,ammountTendered,pProducts;
    /*public static void changeC(){
        //mainV OBJ2 =new mainV();

        System.out.println("amount tendered");
        ammountTendered=keyboard.nextDouble();
        double amountToBePaid;
        amountToBePaid=total;

        change=ammountTendered-amountToBePaid;
        ogChange=change;

        hundreds=change/100;
        change=change%100;

        fifties=change/50;
        change=change%50;

        twenties=change/20;
        change=change%20;

        tens=change/10;
        change=change%10;

        fives=change/5;
        change=change%5;

        ones= change/1;
        change=change%1;

        fiftyCent=change/0.5;
        change=change%0.5;

        tenCents=change/0.1;
        change=change%0.1;

        fiveCents =change/0.05;
        change=change%0.05;

        int fiveCentRound = (int) Math.round(fiveCents);

        System.out.println("       VendingMch 2232,WHK,WHK-WEST by FRANS NEKONGO 221004351            ");
        System.out.println("__________________________________________________________________________");
        System.out.println("Item                    Qty                    Price                 Total");
        System.out.println("__________________________________________________________________________");
        System.out.println(" "+productName+"                  "+quantity+"                      "+pricePerItem+"                  "+amountToBePaid+" ");
        System.out.println("__________________________________________________________________________");
        System.out.println("Amount tendered:                                                    "+ammountTendered);
        System.out.print("Change                                                              ");
        System.out.printf("%6.2f", ogChange);
        System.out.println(" ");
        System.out.println("Disbursed as follows: "+(int)hundreds +"x N$100;"+(int)fifties+"x N$50;"+(int)twenties+" x N$20; "+(int)tens+" x N$10; "+(int)fives+" x N$5; "+(int)ones+" x N$1; "+ (int)fiftyCent +" x 50c; "+(int)tenCents+" x 10c; "+fiveCentRound+" x 5c");
        System.out.println("__________________________________________________________________________");
        System.out.println("                    THANK YOU, PLEASE COME AGAIN!                         ");
    }*/
    public static void main(String[]args) {
        //Storage
        ArrayList<String> Pnames =new ArrayList<String>();
        //names
        Pnames.add(0,"Kginger");
        Pnames.add(1,"Ksprite");
        Pnames.add(2,"Kfanta");
        Pnames.add(3,"Kcoke");
        Pnames.add(4," ");
        Pnames.add(5," ");

        ArrayList<Double> Pprices =new ArrayList<Double>();
        //prices
        Pprices.add(0,11.50);
        Pprices.add(1,12.0);
        Pprices.add(2,12.0);
        Pprices.add(3,15.0);
        Pprices.add(4,0.0);
        Pprices.add(5,0.0);

        ArrayList<Integer> Pquantities =new ArrayList<Integer>();
        //quantities
        Pquantities.add(0,30);
        Pquantities.add(1,30);
        Pquantities.add(2,30);
        Pquantities.add(3,30);
        Pquantities.add(4,0);
        Pquantities.add(5,0);

        //select if you are a customer or an admin//
       System.out.println("to select Items press 1,for admin 2");
        System.out.println("selectction: ");
        int selection=keyboard.nextInt(),j = 0;
        if (selection==1){

            //-print items available
            System.out.println(" ----------WELCOME--DEAR--CUSTOMER------------");
            System.out.println("        VendingMch 2232,WHK,WHK-WEST          ");
            System.out.println(" ______________221004351______________________");
            System.out.println("            Products available:               ");
            System.out.println(
                    "0 "+Pnames.get(0)+", "
                    +"1 "+Pnames.get(1)+", "
                    +"2 "+Pnames.get(2)+", "
                    +"3 "+Pnames.get(3)+", "
                    +"4 "+Pnames.get(4)+", "
                    +"5 "+Pnames.get(5));

            System.out.println("Code: ");
            int code= keyboard.nextInt();
            System.out.println("Cost: " + Pprices.get(code));
            pricePerItem=Pprices.get(code);
            productName=Pnames.get(code);
            System.out.println("Quantity:");
            quantity = keyboard.nextInt();
            System.out.println("Order:");
            total= quantity * Pprices.get(code);
        System.out.println("Name: " + Pnames.get(code) + " Quantity: " + quantity +
                    " Price: " + Pprices.get(code) + " Total: " + total);
        System.out.println("get Receipt 1.yes/2.no");
        int answer=keyboard.nextInt();
        if (answer==1){Receipt.changeC(pricePerItem,quantity,productName,total);
        }else if (answer==2) {System.out.println("unable to select this option online version unavailable");}
        else if (answer>2){System.out.println("invalid selection");
        }
        //takes you to admin side
            //asks for entry code
        } else if (selection==2){
            adminNav.runAdmin();
        }
    }
}

