import java.util.ArrayList;
import java.util.Scanner;

public class adminNav {

    public static int qProducts,balance=1000,quantity,b_hundreds=100,b_fifties=100,b_twenties=100,b_tens=100,b_fives=100,b_ones=100,b_fiftyCents=100,b_tenCents=100,b_fiveCents=100;
    public static String productName;
    public static double  pricePerItem,total,ogChange,change,hundreds,fifties,twenties,tens,fives,ones,fiftyCent,tenCents, fiveCents,ammountTendered,pProducts;

    public static  void runAdmin(){
        Scanner keyboard = new Scanner(System.in);

        ArrayList<String> Pnames =new ArrayList<String>();
        //names
        Pnames.add(0," Kginger");
        Pnames.add(1," Ksprite");
        Pnames.add(2," Kfanta");
        Pnames.add(3," Kcoke");
        Pnames.add(4," empty");
        Pnames.add(5," empty");

        ArrayList<Double> Pprices =new ArrayList<Double>();
        //prices
        Pprices.add(0,11.50);
        Pprices.add(1,12.0);
        Pprices.add(2,12.0);
        Pprices.add(3,15.0);
        Pprices.add(4,0.0);
        Pprices.add(5,0.0);

        ArrayList<Integer> Pquantities =new ArrayList<Integer>();
        //quantities
        Pquantities.add(0,30);
        Pquantities.add(1,30);
        Pquantities.add(2,30);
        Pquantities.add(3,30);
        Pquantities.add(4,0);
        Pquantities.add(5,0);

        System.out.println("welcome admin what would you like to do");
        System.out.println("enter admin code");
        int sCode=keyboard.nextInt();
        if (sCode==100101) {

            String answer = "y";

            while (answer.equalsIgnoreCase("y")){

                System.out.println("1.add stock");
                System.out.println("2.change price");
                System.out.println("3.cash out");
                System.out.println("4.cash in");
                System.out.println("5.show items in stock");
                System.out.println("6.show available money");
                System.out.println("7.Print only restocking");
                System.out.println("8.Exit");
                int selection2=keyboard.nextInt();

                switch (selection2){
                    //add stock
                    case 1:System.out.println("Name: ");
                        Pnames.add(keyboard.next());
                        System.out.println("Quantity: ");
                        Pquantities.add(keyboard.nextInt());
                        System.out.println("Price: ");
                        Pprices.add(keyboard.nextDouble());
                        break;
                    //change price
                    case 2:System.out.println("Code, New Price: ");
                        Pprices.set(keyboard.nextInt(), keyboard.nextDouble());
                        break;
                    //cashout
                    case 3:System.out.println("1. 100\n" +
                            "2. 50\n" +
                            "3. 20\n"+
                            "4. 10\n"+
                            "5. 5\n"+
                            "6. 1\n"+
                            "7. 0.5\n"+
                            "8. 0.1\n"+
                            "9. 0.05\n");
                        System.out.println("selection: ");
                        int cCase= keyboard.nextInt();
                        switch (cCase) {
                            case 1:
                                System.out.println("ammount");
                                b_hundreds -= keyboard.nextInt();
                                System.out.println("ammount succesfully chashed out from " + cCase);
                                break;
                            case 2:
                                System.out.println("ammount");
                                b_fifties -= keyboard.nextInt();
                                System.out.println("ammount succesfully chashed out from " + cCase);
                                break;
                            case 3:
                                System.out.println("ammount");
                                b_twenties -= keyboard.nextInt();
                                System.out.println("ammount succesfully chashed out from " + cCase);
                                break;
                            case 4:
                                System.out.println("ammount");
                                b_tens -= keyboard.nextInt();
                                System.out.println("ammount succesfully chashed out from " + cCase);
                                break;
                            case 5:
                                System.out.println("ammount");
                                b_fives -= keyboard.nextInt();
                                System.out.println("ammount succesfully chashed out from " + cCase);
                                break;
                            case 6:
                                System.out.println("ammount");
                                b_ones -= keyboard.nextInt();
                                System.out.println("ammount succesfully chashed out from " + cCase);
                                break;
                            case 7:
                                System.out.println("ammount");
                                b_fiftyCents -= keyboard.nextInt();
                                System.out.println("ammount succesfully chashed out from " + cCase);
                                break;
                            case 8:
                                System.out.println("ammount");
                                b_tenCents -= keyboard.nextInt();
                                System.out.println("ammount succesfully chashed out from " + cCase);
                                break;
                            case 9:
                                System.out.println("ammount");
                                b_fiveCents -= keyboard.nextInt();
                                System.out.println("ammount succesfully chashed out from " + cCase);
                                break;
                        }break;
                        //cash in
                    case 4:System.out.println("1. 100\n" +
                            "2. 50\n" +
                            "3. 20\n"+
                            "4. 10\n"+
                            "5. 5\n"+
                            "6. 1\n"+
                            "7. 0.5\n"+
                            "8. 0.1\n"+
                            "9. 0.05\n");
                        System.out.println("selection: ");
                        cCase= keyboard.nextInt();
                        switch (cCase) {
                            case 1:
                                System.out.println("ammount");
                                b_hundreds += keyboard.nextInt();
                                System.out.println("ammount succesfully chashed in to " + cCase);
                                break;
                            case 2:
                                System.out.println("ammount");
                                b_fifties += keyboard.nextInt();
                                System.out.println("ammount succesfully chashed in to " + cCase);
                                break;
                            case 3:
                                System.out.println("ammount");
                                b_twenties += keyboard.nextInt();
                                System.out.println("ammount succesfully chashed in to " + cCase);
                                break;
                            case 4:
                                System.out.println("ammount");
                                b_tens += keyboard.nextInt();
                                System.out.println("ammount succesfully chashed in to " + cCase);
                                break;
                            case 5:
                                System.out.println("ammount");
                                b_fives += keyboard.nextInt();
                                System.out.println("ammount succesfully chashed in to " + cCase);
                                break;
                            case 6:
                                System.out.println("ammount");
                                b_ones += keyboard.nextInt();
                                System.out.println("ammount succesfully chashed in to " + cCase);
                                break;
                            case 7:
                                System.out.println("ammount");
                                b_fiftyCents += keyboard.nextInt();
                                System.out.println("ammount succesfully chashed in to " + cCase);
                                break;
                            case 8:
                                System.out.println("ammount");
                                b_tenCents += keyboard.nextInt();
                                System.out.println("ammount succesfully chashed in to " + cCase);
                                break;
                            case 9:
                                System.out.println("ammount");
                                b_fiveCents += keyboard.nextInt();
                                System.out.println("ammount succesfully chashed in to " + cCase);
                                break;
                        }break;
                        //items in stock
                    case 5:System.out.println("Summary:");
                        for (int i = 0; i < Pquantities.size(); i++) {
                            System.out.println(i + " Name: " + Pnames.get(i) + " Quantity: " + Pquantities.get(i) + " Price: " + Pprices.get(i));}break;
                    //show available money
                    case 6:
                        System.out.println("100: " + b_hundreds);
                        System.out.println("50: " + b_fifties);
                        System.out.println("20: " + b_twenties);
                        System.out.println("10: " + b_tens);
                        System.out.println("5: " + b_fives);
                        System.out.println("1: " + b_ones);
                        System.out.println("0.5: " + b_fiftyCents);
                        System.out.println("0.1: " + b_tenCents);
                        System.out.println("0.05: " + b_fiveCents);
                        break;
                    //show restock
                    case 7:System.out.println("Re-stock:");
                    System.out.println("items at code:");
                        for (int i = 0; i < Pquantities.size(); i++) {
                            if (Pquantities.get(i) < 25) {
                                System.out.println(i+Pnames.get(i));
                            }
                        }break;
                    //exit
                    case 8:System.out.println("bye");
                    System.exit(0);break;
                }

                System.out.println("Would you like to continue? (y/n)");
                answer = keyboard.next();
            }

        }else {
            System.out.println("wrong password or invalid entry");
            System.exit(0);}
    }

   public static void main(String[] args) {
        runAdmin();
    }
}
