import java.util.Scanner;
public class Receipt {
    public static int qProducts,balance=1000,b_hundreds=100,b_fifties=100,b_twenties=100,b_tens=100,b_fives=100,b_ones=100,b_fiftyCents=100,b_tenCents=100,b_fiveCents=100;
    public static double  total,ogChange,change,hundreds,fifties,twenties,tens,fives,ones,fiftyCent,tenCents, fiveCents,ammountTendered,pProducts;
    public static Scanner keyboard=new Scanner(System.in);
    public static void changeC(double pricePerItem,int quantity,String productName,double total){

        System.out.println("amount tendered");
        ammountTendered=keyboard.nextDouble();

        double amountToBePaid=total;

        change=ammountTendered-amountToBePaid;
        ogChange=change;

        hundreds=change/100;
        change=change%100;

        fifties=change/50;
        change=change%50;

        twenties=change/20;
        change=change%20;

        tens=change/10;
        change=change%10;

        fives=change/5;
        change=change%5;

        ones= change/1;
        change=change%1;

        fiftyCent=change/0.5;
        change=change%0.5;

        tenCents=change/0.1;
        change=change%0.1;

        fiveCents =change/0.05;
        change=change%0.05;

        int fiveCentRound = (int) Math.round(fiveCents);

        System.out.println("       VendingMch 2232,WHK,WHK-WEST by FRANS NEKONGO 221004351            ");
        System.out.println("__________________________________________________________________________");
        System.out.println("Item                    Qty                    Price                 Total");
        System.out.println("__________________________________________________________________________");
        System.out.println(" "+productName+"                  "+quantity+"                      "+pricePerItem+"                  "+amountToBePaid+" ");
        System.out.println("__________________________________________________________________________");
        System.out.println("Amount tendered:                                                    "+ammountTendered);
        System.out.print("Change                                                              ");
        System.out.printf("%6.2f", ogChange);
        System.out.println(" ");
        System.out.println("Disbursed as follows: "+(int)hundreds +"x N$100;"+(int)fifties+"x N$50;"+(int)twenties+" x N$20; "+(int)tens+" x N$10; "+(int)fives+" x N$5; "+(int)ones+" x N$1; "+ (int)fiftyCent +" x 50c; "+(int)tenCents+" x 10c; "+fiveCentRound+" x 5c");
        System.out.println("__________________________________________________________________________");
        System.out.println("                    THANK YOU, PLEASE COME AGAIN!                         ");
    }
    /*public static void main(String[] args) {
        changeC(productName,total);
    }*/
}